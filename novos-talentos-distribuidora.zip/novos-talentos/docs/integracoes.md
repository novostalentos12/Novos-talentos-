# Integrações de distribuição

A arquitetura deve usar um agregador/distribuidor como camada de entrega quando não existir contrato direto com cada DSP. O backend deve:

- criar/atualizar o release no parceiro;
- enviar metadados e assets segundo o formato exigido;
- guardar o ID externo do release;
- receber status por webhook/polling;
- importar relatórios de streams/receita;
- reconciliar pagamentos e splits.

O nome das plataformas no painel é apenas destino funcional. A distribuição efetiva depende dos contratos e APIs do parceiro escolhido. Não declarar uma música como "ao vivo" até receber confirmação do parceiro/DSP.
