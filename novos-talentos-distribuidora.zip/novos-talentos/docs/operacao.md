# Operação

1. Administrador cria o artista.
2. Artista/administrador cria o lançamento.
3. Inserir áudio, capa e metadados.
4. Confirmar que todos os direitos e autorizações estão regularizados.
5. Validar créditos, splits, ISRC e UPC/EAN.
6. Enviar ao agregador/distribuidor parceiro.
7. Acompanhar cada plataforma no painel.
8. Após os relatórios do parceiro, importar streams e receitas.
9. Gerar relatórios por artista e período.

### Regras de segurança
- MFA para administradores.
- Tokens/API keys somente no servidor.
- Logs de alterações.
- Backup do catálogo e metadados.
- Controle de permissões por função.
