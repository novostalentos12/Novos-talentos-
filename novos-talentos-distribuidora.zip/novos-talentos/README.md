# Novos Talentos — Distribuidora Musical

Starter completo para uma distribuidora musical com painel de administrador.

## O que está incluído
- Landing page da Novos Talentos
- Painel administrativo responsivo
- Cadastro de artistas
- Gestão de lançamentos e faixas
- Gestão de royalties/relatórios
- Estado de distribuição por plataforma
- Estrutura de API backend
- Modelo de dados SQL
- Checklist de integração com DSP/agragador
- Política de direitos e metadados

## Importante
Este projeto é uma base operacional de software. Ele **não cria automaticamente contas de distribuição nas plataformas nem ganha acesso administrativo às contas do utilizador**. Para distribuição real, é necessário contratar/ligar um distribuidor/agregador que tenha contratos ou integrações de entrega com DSPs e configurar credenciais/API de forma segura.

Nunca coloque senhas, tokens ou chaves API diretamente no frontend.

## Estrutura
- `frontend/index.html` — site público
- `frontend/admin.html` — painel administrativo
- `frontend/app.js` — lógica demo do painel
- `frontend/styles.css` — estilos
- `backend/server.js` — API Node/Express de referência
- `backend/.env.example` — variáveis de ambiente
- `backend/schema.sql` — esquema PostgreSQL
- `docs/operacao.md` — fluxo de operação
- `docs/integracoes.md` — arquitetura de integrações

## Como testar o frontend
Abra `frontend/index.html` e `frontend/admin.html` no navegador. O painel usa dados de demonstração locais.

## Próximo passo para produção
1. Registrar o domínio e a empresa/marca.
2. Escolher um agregador/distribuidor que aceite o catálogo e forneça entrega para DSPs.
3. Criar contas de pagamento e de direitos autorais apropriadas.
4. Configurar PostgreSQL, armazenamento de áudio/capas e autenticação segura.
5. Ligar o backend ao agregador através das credenciais oficiais.
6. Implementar validação de ISRC/UPC, direitos, splits e relatórios.
