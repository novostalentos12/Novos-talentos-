const express=require('express');const app=express();app.use(express.json());
const releases=[];const artists=[];
app.get('/api/health',(req,res)=>res.json({ok:true,service:'Novos Talentos API'}));
app.get('/api/artists',(req,res)=>res.json(artists));
app.post('/api/artists',(req,res)=>{const x={id:Date.now(),...req.body};artists.push(x);res.status(201).json(x)});
app.get('/api/releases',(req,res)=>res.json(releases));
app.post('/api/releases',(req,res)=>{const x={id:Date.now(),status:'draft',...req.body};releases.push(x);res.status(201).json(x)});
app.listen(process.env.PORT||3000,()=>console.log('Novos Talentos API running'));
