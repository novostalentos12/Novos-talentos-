function newRelease(){alert('Novo lançamento: no ambiente de produção, este botão abrirá o formulário de áudio, capa, metadados, ISRC/UPC, créditos, splits e destino de distribuição.');}
